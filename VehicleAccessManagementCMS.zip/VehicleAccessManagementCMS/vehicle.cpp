#include "vehicle.h"

Vehicle::Vehicle()
{
}

Vehicle::Vehicle(string license, string inTime, string outTime)
{
	vehicle->license = license;
	vehicle->inTime = inTime;
	vehicle->outTime = outTime;
	vehicle->charge = 0.0;
	
}