#pragma once

#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Vehicle {
public :
	Vehicle();
	Vehicle(string license, string inTime, string  outTime);
	struct Node
	{
		//���� �볡 �볡.
		string license;
		string inTime;
		string outTime;
		double charge;
		Node* next;
	};
	Node* vehicle = new Node;
};

#endif // !VEHICLE_H

