#ifndef MENU_H
#define MENU_H
#pragma once

#include <stdlib.h>
#include <iostream>
using namespace std;
class Menu {
public:
	void mainmenu();//���˵�
	void start();
	void quit();
};

#endif